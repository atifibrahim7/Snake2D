//
//

#ifndef HELLOSFML_BINARYNODE_H
#define HELLOSFML_BINARYNODE_H
#include <string>
#include <iostream>

template<class ItemType>
class BinaryNode
{
private:
    ItemType data;
    BinaryNode<ItemType>* left;
    BinaryNode<ItemType>* right;

public:
    BinaryNode(const ItemType& newData, BinaryNode<ItemType>* newLeft = nullptr, BinaryNode<ItemType>* newRight = nullptr)
            : data(newData), left(newLeft), right(newRight) {}

    ItemType getData() const { return data;

    }
    BinaryNode<ItemType>* getLeft() const {
        return left;
    }

    BinaryNode<ItemType>* getRight() const {
        return right;
    }

    void setLeft(BinaryNode<ItemType>* newLeft) {
        left = newLeft;
    }
    void setRight(BinaryNode<ItemType>* newRight) {
        right = newRight;
    }
};
#endif //HELLOSFML_BINARYNODE_H
