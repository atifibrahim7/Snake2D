//
//

#ifndef HELLOSFML_BINARYTREE_H
#define HELLOSFML_BINARYTREE_H
#include <iostream>
#include "BinaryNode.h"
#include <string>
using namespace std;
template<class ItemType>
class BinaryTree
{
private:
    BinaryNode<ItemType>* root;
    BinaryNode<ItemType>* current;  // Add this member variable

public:
    BinaryTree() : root(nullptr), current(nullptr){}

    ~BinaryTree() { destroyTree(root); }

    BinaryNode<ItemType>* getCurrent() const {
        return current;
    }
    BinaryNode<ItemType>* getRoot() const {
        return root;
    }
    void setCurrent(BinaryNode<ItemType>* newCurrent) {
        current = newCurrent;
    }
    void destroyTree(BinaryNode<ItemType>* node);
    void clearTree();

    bool isEmpty() const;
    void insert(const ItemType& newData);
    void askQuestions();
};

template<class ItemType>
void BinaryTree<ItemType>::destroyTree(BinaryNode<ItemType>* node)
{
    if (node != nullptr)
    {
        destroyTree(node->getLeft());   // Pass the left child pointer
        destroyTree(node->getRight());  // Pass the right child pointer
        delete node;
    }
}

template<class ItemType>
void BinaryTree<ItemType>::clearTree()
{
    destroyTree(root);
    root = nullptr;
}


template<class ItemType>
bool BinaryTree<ItemType>::isEmpty() const
{
    return root == nullptr;
}

#include <queue>

template<class ItemType>
void BinaryTree<ItemType>::insert(const ItemType& newData)
{
    BinaryNode<ItemType>* newNode = new BinaryNode<ItemType>(newData);

    if (isEmpty())
    {
        root = newNode;
        return;
    }

    queue<BinaryNode<ItemType>*> nodeQueue;
    nodeQueue.push(root);

    while (!nodeQueue.empty())
    {
        BinaryNode<ItemType>* current = nodeQueue.front();
        nodeQueue.pop();

        if (current->getLeft() == nullptr)
        {
            current->setLeft(newNode);
            break;
        }
        else if (current->getRight() == nullptr)
        {
            current->setRight(newNode);
            break;
        }
        else
        {
            nodeQueue.push(current->getLeft());
            nodeQueue.push(current->getRight());
        }
    }
}

template<class ItemType>
void BinaryTree<ItemType>::askQuestions() {
    BinaryNode<ItemType> *current = root;

    while (current != nullptr) {
        cout << current->getData() << " (yes/no): " << endl;
        string answer;
        cin >> answer;

        if (answer == "yes") {
            current = current->getLeft();
        } else if (answer == "no") {
            current = current->getRight();
        } else {
            cout << "Invalid input. Please enter 'yes' or 'no'.\n\n";
        }
        if (current == nullptr && answer == "no") {
            cout << "Starting over..." << endl;
            current = root;
        }
    }
}
#endif //HELLOSFML_BINARYTREE_H
