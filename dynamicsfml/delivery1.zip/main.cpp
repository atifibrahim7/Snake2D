#include <SFML/Graphics.hpp>
#include "BinaryTree.h"
#include "BinaryNode.h"
#include <iostream>
#include <string>
using namespace sf;
int main()
{
    BinaryTree<std::string> decisionTree;
    decisionTree.insert("Will it be cold?");
    decisionTree.insert("Will it rain?");
    decisionTree.insert("Is the tarmac prone\n to degredation?");
    decisionTree.insert("Heavy Rain?");
    decisionTree.insert("Is the tarmac prone\n to degredation?");
    decisionTree.insert(">2 stints?");
    decisionTree.insert(">2 stints?");
    decisionTree.insert("Full Wets");
    decisionTree.insert(">2 stints?");
    decisionTree.insert("Mediums");
    decisionTree.insert(">2 stints?");
    decisionTree.insert("Mediums");
    decisionTree.insert("Hards");
    decisionTree.insert("Softs");
    decisionTree.insert("Mediums");
    decisionTree.insert("Final race?");
    decisionTree.insert("Good result?");
    decisionTree.insert("Inters");
    decisionTree.insert("Full Wets");
    decisionTree.insert("Final race?");
    decisionTree.insert("Good result?");
    decisionTree.insert("Softs");
    decisionTree.insert("Mediums");
    decisionTree.insert("Final race?");
    decisionTree.insert("Good result?");
    decisionTree.insert("Final race?");
    decisionTree.insert("Good result?");
    decisionTree.insert("Final race?");
    decisionTree.insert("Good result?");
    decisionTree.insert("Final race?");
    decisionTree.insert("Good result?");



    sf::RenderWindow window(sf::VideoMode(700, 700), "Optimal Tire Composition");

    Sprite spriteBg; 
    Texture textureBg;
    if (!textureBg.loadFromFile("bg.jpg"))   cout << "bgnotloaded";
    spriteBg.setTexture(textureBg);
    spriteBg.setPosition(0, 0);
    spriteBg.setScale(1 , 1.8);
    sf::Font font;
    if (!font.loadFromFile("myFont.ttf")) {
        return 1;
    }
    // question : 
    sf::Text questionText;
    questionText.setFont(font);
    questionText.setCharacterSize(24);
    questionText.setPosition(200, 300);
    questionText.setFillColor(sf::Color::White);
    questionText.setScale(1.5, 1.5);
    BinaryNode<std::string>* currentNode = decisionTree.getRoot();

   
    // game loop
    while (window.isOpen())
    {

        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
            else if (event.type == sf::Event::KeyPressed)
            {
                if (event.key.code == sf::Keyboard::Y)
                {
                    currentNode = currentNode->getLeft();
                    cout << "left";
                }
                else if (event.key.code == sf::Keyboard::N)
                {
                    currentNode = currentNode->getRight();
                    cout << "right";
                }
            }
        }


        window.clear();
        window.draw(spriteBg);
        //Graphics
        
        if (currentNode != nullptr) {
            questionText.setString( currentNode->getData() + "\nYes(Y)\t\tNo(N)");
            window.draw(questionText);
        }
        else {
            cout << "\nReached the end "; 
            break;
        }
        window.display();
    }
    // game loop end 
    return 0;
}
